import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import Chat from './components/Chat';
import ImageGeneration from './components/ImageGeneration';
import Dashboard from './components/Dashboard';
import History from './components/History';
import './App.css';

function App() {
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    // Initialize user session
    initializeUser();
  }, []);

  const initializeUser = async () => {
    try {
      const response = await fetch('/api/user/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      setUserId(data.sessionId);
    } catch (error) {
      console.error('Failed to initialize user:', error);
      // Fallback to temporary ID
      setUserId('temp_' + Date.now());
    }
  };

  if (!userId) {
    return (
      <div className="loading">
        <h2>Initializing VirtualIEC...</h2>
      </div>
    );
  }

  return (
    <Router>
      <div className="app">
        <nav className="navbar">
          <div className="nav-brand">
            <h1>VirtualIEC</h1>
            <span>AI-Powered Platform</span>
          </div>
          <div className="nav-links">
            <Link to="/chat" className="nav-link">Chat</Link>
            <Link to="/image" className="nav-link">Images</Link>
            <Link to="/dashboard" className="nav-link">Dashboard</Link>
            <Link to="/history" className="nav-link">History</Link>
          </div>
        </nav>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/chat" element={<Chat userId={userId} />} />
            <Route path="/image" element={<ImageGeneration userId={userId} />} />
            <Route path="/dashboard" element={<Dashboard userId={userId} />} />
            <Route path="/history" element={<History userId={userId} />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;