import React, { useState, useEffect, useRef } from 'react';

function Chat({ userId }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [selectedModel, setSelectedModel] = useState('gpt-5');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const availableModels = [
    { id: 'gpt-5', name: 'GPT-5 (Latest)' },
    { id: 'gpt-4', name: 'GPT-4' },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' }
  ];

  useEffect(() => {
    loadChatHistory();
  }, [userId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadChatHistory = async () => {
    try {
      const response = await fetch(`/api/chat/${userId}`);
      const data = await response.json();
      setMessages(data.messages || []);
    } catch (error) {
      console.error('Failed to load chat history:', error);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const messageText = inputValue.trim();
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          message: messageText,
          model: selectedModel
        })
      });

      const data = await response.json();
      
      // Reload chat history to get the complete conversation
      await loadChatHistory();
    } catch (error) {
      console.error('Failed to send message:', error);
      // Add error message to chat
      const errorMessage = {
        id: Date.now(),
        role: 'error',
        content: 'Failed to send message. Please try again.',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="page-container">
      <h2 className="page-title">AI Chat Interface</h2>
      
      <div className="card" style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
          <label htmlFor="model-select"><strong>AI Model:</strong></label>
          <select 
            id="model-select"
            value={selectedModel} 
            onChange={(e) => setSelectedModel(e.target.value)}
            style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          >
            {availableModels.map(model => (
              <option key={model.id} value={model.id}>
                {model.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="card" style={{ height: '400px', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, overflowY: 'auto', padding: '1rem', border: '1px solid #e0e0e0', borderRadius: '8px', marginBottom: '1rem' }}>
          {messages.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#666', padding: '2rem' }}>
              <p>Welcome to VirtualIEC Chat!</p>
              <p>Start a conversation with AI using the input below.</p>
            </div>
          ) : (
            messages.map((message) => (
              <div 
                key={message.id}
                style={{
                  marginBottom: '1rem',
                  padding: '1rem',
                  borderRadius: '8px',
                  backgroundColor: message.role === 'user' ? '#e3f2fd' : 
                                   message.role === 'error' ? '#ffebee' : '#f5f5f5'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                  <strong>
                    {message.role === 'user' ? 'You' : 
                     message.role === 'error' ? 'Error' : `AI (${message.model})`}
                  </strong>
                  <small style={{ color: '#666' }}>
                    {formatTimestamp(message.timestamp)}
                  </small>
                </div>
                <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{message.content}</p>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '0.5rem' }}>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={`Type your message for ${selectedModel}...`}
            className="input"
            style={{ flex: 1 }}
            disabled={isLoading}
          />
          <button type="submit" className="button" disabled={isLoading || !inputValue.trim()}>
            {isLoading ? 'Sending...' : 'Send'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default Chat;