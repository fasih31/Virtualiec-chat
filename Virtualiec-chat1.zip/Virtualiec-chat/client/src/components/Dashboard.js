import React, { useState, useEffect } from 'react';

function Dashboard({ userId }) {
  const [apiStatus, setApiStatus] = useState('checking...');

  useEffect(() => {
    checkApiHealth();
  }, []);

  const checkApiHealth = async () => {
    try {
      const response = await fetch('/api/health');
      const data = await response.json();
      setApiStatus('✅ Connected');
    } catch (error) {
      setApiStatus('❌ Disconnected');
    }
  };

  return (
    <div className="page-container">
      <h2 className="page-title">VirtualIEC Dashboard</h2>
      
      <div className="card">
        <h3>Welcome to VirtualIEC</h3>
        <p>Your AI-powered chat and productivity platform is ready to use.</p>
        
        <div style={{ marginTop: '2rem' }}>
          <h4>System Status</h4>
          <p><strong>API Status:</strong> {apiStatus}</p>
          <p><strong>User ID:</strong> {userId}</p>
          <p><strong>Platform:</strong> Multi-LLM Ready</p>
        </div>

        <div style={{ marginTop: '2rem' }}>
          <h4>Available Features</h4>
          <ul>
            <li>🤖 Multi-LLM Chat Interface</li>
            <li>🎨 AI Image Generation</li>
            <li>📱 Multi-page Architecture</li>
            <li>💾 In-memory Storage (MVP)</li>
            <li>🔧 Modular Plugin System</li>
          </ul>
        </div>

        <button className="button" onClick={() => window.location.href = '/chat'}>
          Start Chatting
        </button>
      </div>
    </div>
  );
}

export default Dashboard;