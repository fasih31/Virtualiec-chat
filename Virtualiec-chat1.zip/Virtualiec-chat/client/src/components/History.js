import React, { useState, useEffect } from 'react';

function History({ userId }) {
  const [chatHistory, setChatHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, [userId]);

  const loadHistory = async () => {
    try {
      const response = await fetch(`/api/chat/${userId}`);
      const data = await response.json();
      setChatHistory(data.messages || []);
    } catch (error) {
      console.error('Failed to load history:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = async () => {
    if (!window.confirm('Are you sure you want to clear all chat history? This action cannot be undone.')) {
      return;
    }
    
    try {
      // For now, just clear local state - in a real app you'd call an API endpoint
      setChatHistory([]);
      alert('History cleared successfully!');
    } catch (error) {
      console.error('Failed to clear history:', error);
      alert('Failed to clear history. Please try again.');
    }
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString();
  };

  const groupMessagesByDate = (messages) => {
    const groups = {};
    messages.forEach(message => {
      const date = new Date(message.timestamp).toDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(message);
    });
    return groups;
  };

  if (loading) {
    return (
      <div className="page-container">
        <h2 className="page-title">Loading History...</h2>
      </div>
    );
  }

  const groupedMessages = groupMessagesByDate(chatHistory);
  const dates = Object.keys(groupedMessages).sort((a, b) => new Date(b) - new Date(a));

  return (
    <div className="page-container">
      <h2 className="page-title">Chat History</h2>
      
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div>
            <p><strong>Total Messages:</strong> {chatHistory.length}</p>
            <p><strong>User ID:</strong> {userId}</p>
          </div>
          {chatHistory.length > 0 && (
            <button 
              onClick={clearHistory}
              style={{
                background: '#dc3545',
                color: 'white',
                border: 'none',
                padding: '0.5rem 1rem',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Clear History
            </button>
          )}
        </div>
      </div>

      {chatHistory.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
          <p style={{ color: '#666', fontSize: '1.2rem' }}>No chat history yet.</p>
          <p>Start a conversation in the Chat tab to see your history here.</p>
          <button 
            className="button" 
            onClick={() => window.location.href = '/chat'}
            style={{ marginTop: '1rem' }}
          >
            Start Chatting
          </button>
        </div>
      ) : (
        dates.map(date => (
          <div key={date} className="card">
            <h3 style={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              margin: '-1.5rem -1.5rem 1rem -1.5rem',
              padding: '1rem 1.5rem',
              borderRadius: '8px 8px 0 0'
            }}>
              {date}
            </h3>
            
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {groupedMessages[date].map((message, index) => (
                <div 
                  key={message.id || index}
                  style={{
                    marginBottom: '1rem',
                    padding: '0.75rem',
                    borderRadius: '6px',
                    backgroundColor: message.role === 'user' ? '#e3f2fd' : '#f5f5f5',
                    borderLeft: `4px solid ${message.role === 'user' ? '#2196f3' : '#4caf50'}`
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <strong>
                      {message.role === 'user' ? 'You' : `AI (${message.model || 'Unknown'})`}
                    </strong>
                    <small style={{ color: '#666' }}>
                      {formatDate(message.timestamp)}
                    </small>
                  </div>
                  <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{message.content}</p>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default History;