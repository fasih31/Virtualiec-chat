import React, { useState } from 'react';

function ImageGeneration({ userId }) {
  const [prompt, setPrompt] = useState('');
  const [generatedImage, setGeneratedImage] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState([]);

  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          userId
        })
      });

      const data = await response.json();
      const imageData = {
        ...data,
        id: Date.now(),
        prompt: prompt.trim()
      };

      setGeneratedImage(imageData);
      setHistory(prev => [imageData, ...prev]);
      setPrompt('');
    } catch (error) {
      console.error('Failed to generate image:', error);
      alert('Failed to generate image. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const samplePrompts = [
    "A futuristic AI robot working at a computer",
    "Digital art of a neural network visualization",
    "Abstract representation of artificial intelligence",
    "Cyberpunk cityscape with neon lights",
    "Minimalist tech workspace with holographic displays"
  ];

  return (
    <div className="page-container">
      <h2 className="page-title">AI Image Generation</h2>
      
      <div className="card">
        <form onSubmit={handleGenerate}>
          <label htmlFor="prompt-input" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Image Prompt:
          </label>
          <textarea
            id="prompt-input"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to generate..."
            className="textarea"
            rows={3}
            disabled={isGenerating}
          />
          
          <button 
            type="submit" 
            className="button" 
            style={{ marginTop: '1rem', width: '100%' }}
            disabled={isGenerating || !prompt.trim()}
          >
            {isGenerating ? 'Generating Image...' : 'Generate Image'}
          </button>
        </form>

        <div style={{ marginTop: '1.5rem' }}>
          <h4>Sample Prompts:</h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            {samplePrompts.map((samplePrompt, index) => (
              <button
                key={index}
                onClick={() => setPrompt(samplePrompt)}
                style={{
                  background: 'none',
                  border: '1px solid #667eea',
                  color: '#667eea',
                  padding: '0.5rem',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '0.8rem'
                }}
                disabled={isGenerating}
              >
                {samplePrompt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {generatedImage && (
        <div className="card">
          <h3>Generated Image</h3>
          <div style={{ textAlign: 'center' }}>
            <img 
              src={generatedImage.url} 
              alt={generatedImage.prompt}
              style={{ 
                maxWidth: '100%', 
                height: 'auto', 
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }} 
            />
            <p style={{ marginTop: '1rem', fontStyle: 'italic', color: '#666' }}>
              "{generatedImage.prompt}"
            </p>
            <p style={{ fontSize: '0.8rem', color: '#888' }}>
              Generated at: {new Date(generatedImage.timestamp).toLocaleString()}
            </p>
          </div>
        </div>
      )}

      {history.length > 1 && (
        <div className="card">
          <h3>Generation History</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
            {history.slice(1).map((image, index) => (
              <div key={image.id} style={{ textAlign: 'center' }}>
                <img 
                  src={image.url} 
                  alt={image.prompt}
                  style={{ 
                    width: '100%', 
                    height: '150px', 
                    objectFit: 'cover', 
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                  onClick={() => setGeneratedImage(image)}
                />
                <p style={{ fontSize: '0.7rem', margin: '0.5rem 0', color: '#666' }}>
                  {image.prompt.length > 50 ? image.prompt.substring(0, 50) + '...' : image.prompt}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default ImageGeneration;