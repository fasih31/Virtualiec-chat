const express = require('express');
const cors = require('cors');
const path = require('path');
const OpenAIService = require('./services/openaiService');
const { PluginManager } = require('./services/pluginManager');
const DebateOrchestrator = require('./services/debateOrchestrator');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware - Configure CORS for Replit environment
app.use(cors({
  origin: true, // Allow all origins for Replit proxy
  credentials: false
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client/build')));

// Initialize services
const openaiService = new OpenAIService();
const pluginManager = new PluginManager();
const debateOrchestrator = new DebateOrchestrator(openaiService);

// Register demo plugin
const DemoPlugin = require('./plugins/demoPlugin');
pluginManager.registerPlugin('demo', DemoPlugin);

// In-memory storage for MVP
const chatHistory = new Map(); // userId -> messages array (legacy)
const userSessions = new Map(); // sessionId -> user data

// New session-centric storage
const sessionsByUser = new Map(); // userId -> Array<{id, title, createdAt, defaultModel, systemPrompt, messages[]}>
const allSessions = new Map(); // sessionId -> session object
const userPreferences = new Map(); // userId -> {defaultModel, theme, etc.}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'VirtualIEC API is running', 
    timestamp: new Date().toISOString(),
    openai: !!process.env.OPENAI_API_KEY ? 'configured' : 'not configured',
    models: openaiService.getAvailableModels()
  });
});

// Get available models
app.get('/api/models', (req, res) => {
  res.json({ models: openaiService.getAvailableModels() });
});

// Chat endpoints
app.get('/api/chat/:userId', (req, res) => {
  const userId = req.params.userId;
  const messages = chatHistory.get(userId) || [];
  res.json({ messages });
});

app.post('/api/chat', async (req, res) => {
  try {
    const { userId, message, model = 'gpt-5' } = req.body;
    
    // Validate input
    if (!userId || !message) {
      return res.status(400).json({ error: 'userId and message are required' });
    }
    
    // Initialize user history if needed
    if (!chatHistory.has(userId)) {
      chatHistory.set(userId, []);
    }
    
    const userHistory = chatHistory.get(userId);
    
    // Store user message
    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: message,
      model,
      timestamp: new Date().toISOString()
    };
    
    userHistory.push(userMessage);
    
    // Check if any plugin should handle this message first
    const pluginResult = await pluginManager.processMessage(message, { 
      userId, 
      model, 
      history: userHistory.slice(-5) // Give plugins recent context
    });
    
    if (pluginResult && pluginResult.pluginResult) {
      // Plugin handled the message
      const aiMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: pluginResult.pluginResult.content,
        model: `${model} (via ${pluginResult.handledBy})`,
        timestamp: new Date().toISOString(),
        plugin: pluginResult.handledBy
      };
      
      userHistory.push(aiMessage);
      res.json({ message: aiMessage });
      return;
    }

    // Get AI response using OpenAI
    try {
      const aiResponse = await openaiService.chatCompletion(message, model, userHistory);
      
      const aiMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: aiResponse.content,
        model: aiResponse.model,
        timestamp: new Date().toISOString(),
        usage: aiResponse.usage
      };
      
      userHistory.push(aiMessage);
      
      res.json({ message: aiMessage });
    } catch (aiError) {
      // Fallback to echo if OpenAI fails
      console.error('AI service error, falling back to echo:', aiError);
      
      const fallbackMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: `[AI Service Temporarily Unavailable] Echo from ${model}: ${message}`,
        model: `${model} (fallback)`,
        timestamp: new Date().toISOString(),
        error: true
      };
      
      userHistory.push(fallbackMessage);
      res.json({ message: fallbackMessage });
    }
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Failed to process chat message' });
  }
});

// Image generation endpoint
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, userId } = req.body;
    
    // Validate input
    if (!prompt || !userId) {
      return res.status(400).json({ error: 'prompt and userId are required' });
    }
    
    // Generate image using OpenAI DALL-E
    try {
      const imageResult = await openaiService.generateImage(prompt);
      
      res.json({ 
        url: imageResult.url,
        prompt: prompt,
        revisedPrompt: imageResult.revisedPrompt,
        timestamp: new Date().toISOString(),
        userId: userId
      });
    } catch (aiError) {
      console.error('AI image generation error:', aiError);
      
      // Fallback to placeholder
      res.json({ 
        url: 'https://via.placeholder.com/1024x1024/667eea/white?text=Image+Generation+Temporarily+Unavailable',
        prompt,
        timestamp: new Date().toISOString(),
        error: true,
        message: 'Image generation service temporarily unavailable'
      });
    }
  } catch (error) {
    console.error('Image generation error:', error);
    res.status(500).json({ error: 'Failed to generate image' });
  }
});

// === NEW SESSION MANAGEMENT API ENDPOINTS ===

// Helper function to generate unique session ID
const generateSessionId = () => 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);

// Get all sessions for a user
app.get('/api/sessions', (req, res) => {
  const { userId } = req.query;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const userSessionsList = sessionsByUser.get(userId) || [];
  res.json({ sessions: userSessionsList });
});

// Create new chat session
app.post('/api/sessions', (req, res) => {
  const { userId, title, defaultModel = 'gpt-5', systemPrompt = 'You are a helpful AI assistant.' } = req.body;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const sessionId = generateSessionId();
  const newSession = {
    id: sessionId,
    title: title || `Chat ${Date.now()}`,
    createdAt: new Date().toISOString(),
    defaultModel,
    systemPrompt,
    messages: [],
    archived: false,
    ownerId: userId  // Fix: Store ownership for security
  };
  
  // Add to user's sessions
  if (!sessionsByUser.has(userId)) {
    sessionsByUser.set(userId, []);
  }
  sessionsByUser.get(userId).push(newSession);
  
  // Add to global sessions map
  allSessions.set(sessionId, newSession);
  
  res.json({ session: newSession });
});

// Get messages from a specific session
app.get('/api/sessions/:sessionId/messages', (req, res) => {
  const { sessionId } = req.params;
  const { userId } = req.query;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const session = allSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  // Fix: Verify ownership
  if (session.ownerId !== userId) {
    return res.status(403).json({ error: 'Access denied: You do not own this session' });
  }
  
  res.json({ messages: session.messages });
});

// Send message to a specific session
app.post('/api/sessions/:sessionId/messages', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { content, model, userId } = req.body;
    
    if (!content || !userId) {
      return res.status(400).json({ error: 'content and userId are required' });
    }
    
    const session = allSessions.get(sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }
    
    // Fix: Verify ownership
    if (session.ownerId !== userId) {
      return res.status(403).json({ error: 'Access denied: You do not own this session' });
    }
    
    // Use session's default model if not specified
    const selectedModel = model || session.defaultModel;
    
    // Store user message
    const userMessage = {
      id: Date.now(),
      role: 'user',
      content,
      model: selectedModel,
      timestamp: new Date().toISOString()
    };
    
    session.messages.push(userMessage);
    
    // Check if plugin should handle this first
    const pluginResult = await pluginManager.processMessage(content, { 
      sessionId, 
      model: selectedModel, 
      history: session.messages.slice(-5)
    });
    
    if (pluginResult && pluginResult.pluginResult) {
      // Plugin handled the message - fix: use handledBy instead of pluginName
      const aiMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: pluginResult.pluginResult.content,
        model: selectedModel + ' (via ' + pluginResult.handledBy + ')',
        timestamp: new Date().toISOString(),
        plugin: pluginResult.handledBy
      };
      
      session.messages.push(aiMessage);
      return res.json({ message: aiMessage });
    }
    
    // Get AI response using conversation history with session system prompt
    const conversationHistory = session.messages.slice(-10);
    // Apply session system prompt
    const contextWithSystemPrompt = [
      { role: 'system', content: session.systemPrompt },
      ...conversationHistory
    ];
    const aiResponse = await openaiService.chatCompletion(content, selectedModel, contextWithSystemPrompt);
    
    const aiMessage = {
      id: Date.now() + 1,
      role: 'assistant',
      content: aiResponse.content,
      model: aiResponse.model,
      timestamp: new Date().toISOString(),
      usage: aiResponse.usage
    };
    
    session.messages.push(aiMessage);
    res.json({ message: aiMessage });
    
  } catch (error) {
    console.error('Session message error:', error);
    
    // Add AI fallback like legacy chat endpoint
    const fallbackMessage = {
      id: Date.now() + 1,
      role: 'assistant',
      content: `I apologize, but I'm experiencing technical difficulties. Your message was: "${content}". Please try again in a moment. Error: ${error.message}`,
      model: selectedModel + ' (Error Mode)',
      timestamp: new Date().toISOString(),
      error: true
    };
    
    session.messages.push(fallbackMessage);
    res.json({ message: fallbackMessage });
  }
});

// Update session (title, archive status)
app.patch('/api/sessions/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const { title, archived, userId } = req.body;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const session = allSessions.get(sessionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  // Fix: Verify ownership
  if (session.ownerId !== userId) {
    return res.status(403).json({ error: 'Access denied: You do not own this session' });
  }
  
  if (title !== undefined) session.title = title;
  if (archived !== undefined) session.archived = archived;
  
  res.json({ session });
});

// Delete session
app.delete('/api/sessions/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const { userId } = req.query;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const session = allSessions.get(sessionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  // Fix: Verify ownership before deletion
  if (session.ownerId !== userId) {
    return res.status(403).json({ error: 'Access denied: You do not own this session' });
  }
  
  // Remove from user's sessions (use session's actual owner)
  const userSessionsList = sessionsByUser.get(session.ownerId) || [];
  const filteredSessions = userSessionsList.filter(s => s.id !== sessionId);
  sessionsByUser.set(session.ownerId, filteredSessions);
  
  // Remove from global sessions
  allSessions.delete(sessionId);
  
  res.json({ success: true });
});

// Get user preferences
app.get('/api/user/preferences', (req, res) => {
  const { userId } = req.query;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const preferences = userPreferences.get(userId) || {
    defaultModel: 'gpt-5',
    theme: 'dark'
  };
  
  res.json({ preferences });
});

// Update user preferences
app.put('/api/user/preferences', (req, res) => {
  const { userId, defaultModel, theme } = req.body;
  
  if (!userId) {
    return res.status(400).json({ error: 'userId is required' });
  }
  
  const preferences = userPreferences.get(userId) || {};
  if (defaultModel) preferences.defaultModel = defaultModel;
  if (theme) preferences.theme = theme;
  
  userPreferences.set(userId, preferences);
  res.json({ preferences });
});

// === DEBATE ORCHESTRATOR ENDPOINTS ===

// Get available debate topics
app.get('/api/debate/topics', (req, res) => {
  const topics = debateOrchestrator.getDebateTopics();
  res.json({ topics });
});

// Run a multi-LLM debate
app.post('/api/debate', async (req, res) => {
  try {
    const { userId, topic, modelA, modelB, rounds = 3, judgeModel } = req.body;
    
    // Validate required fields
    if (!userId || !topic) {
      return res.status(400).json({ error: 'userId and topic are required' });
    }
    
    // Validate debate configuration
    const validation = debateOrchestrator.validateDebateConfig({
      topic, 
      modelA: modelA || 'gpt-5', 
      modelB: modelB || 'gpt-4', 
      rounds, 
      judgeModel
    });
    
    if (!validation.valid) {
      return res.status(400).json({ 
        error: 'Invalid debate configuration', 
        details: validation.errors 
      });
    }
    
    // Run the debate
    console.log(`🎯 Starting debate for user ${userId}: "${topic}"`);
    const debateResult = await debateOrchestrator.runDebate({
      topic,
      modelA: modelA || 'gpt-5',
      modelB: modelB || 'gpt-4',
      rounds,
      judgeModel
    });
    
    // Store debate result (optional - for future history feature)
    const debateId = 'debate_' + Date.now();
    debateResult.id = debateId;
    debateResult.userId = userId;
    
    console.log(`✅ Debate completed: ${debateResult.transcript.length} messages`);
    
    res.json({ 
      debate: debateResult,
      message: 'Debate completed successfully'
    });
    
  } catch (error) {
    console.error('Debate API error:', error);
    res.status(500).json({ 
      error: 'Failed to run debate', 
      message: error.message 
    });
  }
});

// User management
app.post('/api/user/session', (req, res) => {
  const sessionId = 'user_' + Date.now();
  const userData = {
    id: sessionId,
    createdAt: new Date().toISOString(),
    lastActivity: new Date().toISOString()
  };
  
  userSessions.set(sessionId, userData);
  res.json({ sessionId, user: userData });
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// Serve the main app
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`VirtualIEC server running on http://0.0.0.0:${PORT}`);
  console.log(`API available at http://0.0.0.0:${PORT}/api`);
});
