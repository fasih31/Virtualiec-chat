/**
 * Debate Orchestrator for VirtualIEC
 * Coordinates debates between two AI models with optional judge verdict
 */

class DebateOrchestrator {
  constructor(openaiService) {
    this.openaiService = openaiService;
  }

  /**
   * Run a debate between two AI models
   * @param {Object} config - Debate configuration
   * @param {string} config.topic - The debate topic
   * @param {string} config.modelA - First model (Pro side)
   * @param {string} config.modelB - Second model (Con side)
   * @param {number} config.rounds - Number of debate rounds (default: 3)
   * @param {string} config.judgeModel - Optional judge model for final verdict
   * @returns {Object} Debate transcript and optional verdict
   */
  async runDebate({ topic, modelA = 'gpt-5', modelB = 'gpt-4', rounds = 3, judgeModel = null }) {
    const transcript = [];
    const maxMessageLength = 300; // Keep responses concise for back-and-forth

    // System prompts for each model
    const proPrompt = `You are participating in a structured debate. You are arguing FOR the topic: "${topic}". 
    Keep your responses under ${maxMessageLength} words, be persuasive, use evidence, and address counterarguments. 
    This is round-based, so make each response count. Stay focused on the topic.`;

    const conPrompt = `You are participating in a structured debate. You are arguing AGAINST the topic: "${topic}". 
    Keep your responses under ${maxMessageLength} words, be persuasive, use evidence, and address counterarguments. 
    This is round-based, so make each response count. Stay focused on the topic.`;

    // Keep track of conversation history for context
    const conversationHistory = [];

    try {
      // Opening statements
      console.log(`🎯 Starting debate: "${topic}"`);
      console.log(`📢 Pro: ${modelA} | Con: ${modelB} | Rounds: ${rounds}`);

      // Round 1: Opening statements
      const proOpening = await this.openaiService.chatCompletion(
        `Present your opening argument FOR: "${topic}"`, 
        modelA, 
        [{ role: 'system', content: proPrompt }]
      );

      const proMessage = {
        speaker: 'Pro',
        model: modelA,
        content: proOpening.content,
        round: 1,
        timestamp: new Date().toISOString(),
        type: 'opening'
      };
      transcript.push(proMessage);
      conversationHistory.push({ role: 'assistant', content: proOpening.content });

      const conOpening = await this.openaiService.chatCompletion(
        `Present your opening argument AGAINST: "${topic}". Here's what the Pro side just argued: "${proOpening.content}"`, 
        modelB,
        [{ role: 'system', content: conPrompt }]
      );

      const conMessage = {
        speaker: 'Con',
        model: modelB,
        content: conOpening.content,
        round: 1,
        timestamp: new Date().toISOString(),
        type: 'opening'
      };
      transcript.push(conMessage);
      conversationHistory.push({ role: 'user', content: conOpening.content });

      // Subsequent rounds: Rebuttals and counter-arguments
      for (let round = 2; round <= rounds; round++) {
        // Pro's turn
        const recentContext = conversationHistory.slice(-4); // Last 2 exchanges for context
        const proRebuttal = await this.openaiService.chatCompletion(
          `This is round ${round}. Respond to the Con side's arguments and strengthen your position FOR: "${topic}"`,
          modelA,
          [{ role: 'system', content: proPrompt }, ...recentContext]
        );

        const proRoundMessage = {
          speaker: 'Pro',
          model: modelA,
          content: proRebuttal.content,
          round: round,
          timestamp: new Date().toISOString(),
          type: 'rebuttal'
        };
        transcript.push(proRoundMessage);
        conversationHistory.push({ role: 'assistant', content: proRebuttal.content });

        // Con's turn
        const conRebuttal = await this.openaiService.chatCompletion(
          `This is round ${round}. Respond to the Pro side's arguments and strengthen your position AGAINST: "${topic}"`,
          modelB,
          [{ role: 'system', content: conPrompt }, ...conversationHistory.slice(-4)]
        );

        const conRoundMessage = {
          speaker: 'Con',
          model: modelB,
          content: conRebuttal.content,
          round: round,
          timestamp: new Date().toISOString(),
          type: 'rebuttal'
        };
        transcript.push(conRoundMessage);
        conversationHistory.push({ role: 'user', content: conRebuttal.content });
      }

      // Optional judge verdict
      let verdict = null;
      if (judgeModel) {
        const debateContext = transcript.map(msg => 
          `${msg.speaker} (${msg.model}): ${msg.content}`
        ).join('\n\n');

        const judgePrompt = `You are an impartial judge evaluating a debate on: "${topic}"
        
        Here is the full debate transcript:
        ${debateContext}
        
        Provide a balanced analysis of both sides and declare which side presented the stronger argument. 
        Consider evidence quality, logical reasoning, addressing counterarguments, and persuasiveness.
        Format: Brief analysis, then "WINNER: Pro" or "WINNER: Con" or "WINNER: Tie"`;

        const judgeResponse = await this.openaiService.chatCompletion(
          'Analyze this debate and provide your verdict.',
          judgeModel,
          [{ role: 'system', content: judgePrompt }]
        );

        verdict = {
          judge: judgeModel,
          analysis: judgeResponse.content,
          timestamp: new Date().toISOString()
        };
      }

      return {
        topic,
        models: { pro: modelA, con: modelB, judge: judgeModel },
        rounds,
        transcript,
        verdict,
        completedAt: new Date().toISOString()
      };

    } catch (error) {
      console.error('Debate orchestration error:', error);
      
      // Return partial results with error info
      return {
        topic,
        models: { pro: modelA, con: modelB, judge: judgeModel },
        rounds,
        transcript,
        verdict: null,
        error: error.message,
        completedAt: new Date().toISOString()
      };
    }
  }

  /**
   * Get available debate topics/templates
   */
  getDebateTopics() {
    return [
      {
        id: 'ai_benefits',
        title: 'AI will benefit humanity more than it will harm it',
        category: 'Technology',
        suggested: true
      },
      {
        id: 'remote_work',
        title: 'Remote work is more productive than office work',
        category: 'Work & Society',
        suggested: true
      },
      {
        id: 'social_media',
        title: 'Social media has done more harm than good to society',
        category: 'Society & Culture',
        suggested: true
      },
      {
        id: 'climate_priority',
        title: 'Climate change should be humanity\'s top priority',
        category: 'Environment',
        suggested: true
      },
      {
        id: 'crypto_currency',
        title: 'Cryptocurrency will replace traditional currency',
        category: 'Economics',
        suggested: false
      },
      {
        id: 'space_exploration',
        title: 'Space exploration is worth the cost',
        category: 'Science',
        suggested: false
      }
    ];
  }

  /**
   * Validate debate configuration
   */
  validateDebateConfig({ topic, modelA, modelB, rounds, judgeModel }) {
    const errors = [];

    if (!topic || topic.trim().length < 10) {
      errors.push('Topic must be at least 10 characters long');
    }

    if (!modelA || !modelB) {
      errors.push('Both models must be specified');
    }

    if (modelA === modelB && (!judgeModel || judgeModel === modelA)) {
      errors.push('At least two different models must be used');
    }

    if (rounds < 1 || rounds > 5) {
      errors.push('Rounds must be between 1 and 5');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }
}

module.exports = DebateOrchestrator;