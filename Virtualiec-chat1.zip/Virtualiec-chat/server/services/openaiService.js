const OpenAI = require('openai');

// Initialize OpenAI client only if API key is available
let openai = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

class OpenAIService {
  constructor() {
    this.models = {
      'gpt-5': 'gpt-5', // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      'gpt-4': 'gpt-4',
      'gpt-3.5-turbo': 'gpt-3.5-turbo'
    };
  }

  async chatCompletion(message, model = 'gpt-5', conversationHistory = []) {
    try {
      // Check if OpenAI client is available
      if (!openai) {
        // Return a fallback response when OpenAI is not configured
        return {
          content: `Hello! VirtualIEC is running in demo mode. Your message was: "${message}". To enable full AI features, please configure the OPENAI_API_KEY environment variable. The platform supports ${model} and other AI models for chat, code generation, and creative tasks.`,
          model: model + ' (Demo Mode)',
          usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
        };
      }

      // Prepare messages array with conversation history
      const messages = [
        {
          role: 'system',
          content: 'You are a helpful AI assistant in VirtualIEC, an AI-powered productivity platform. Be concise, helpful, and engaging.'
        },
        ...conversationHistory.slice(-10).map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        {
          role: 'user',
          content: message
        }
      ];

      const response = await openai.chat.completions.create({
        model: this.models[model] || 'gpt-5',
        messages: messages,
        max_tokens: 2000
        // Note: gpt-5 doesn't support temperature parameter, do not use it.
      });

      return {
        content: response.choices[0].message.content,
        model: model,
        usage: response.usage
      };
    } catch (error) {
      console.error('OpenAI chat completion error:', error);
      // Return a graceful fallback instead of throwing
      return {
        content: `I apologize, but I'm experiencing technical difficulties accessing the AI service. Your message was: "${message}". Please try again in a moment, or contact support if this issue persists. Error: ${error.message}`,
        model: model + ' (Error Mode)',
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
      };
    }
  }

  async generateImage(prompt) {
    try {
      // Check if OpenAI client is available
      if (!openai) {
        // Return a placeholder image URL for demo mode
        return {
          url: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAyNCIgaGVpZ2h0PSIxMDI0IiB2aWV3Qm94PSIwIDAgMTAyNCAxMDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cmVjdCB3aWR0aD0iMTAyNCIgaGVpZ2h0PSIxMDI0IiBmaWxsPSIjRjBGMEYwIi8+CjxwYXRoIGQ9Ik01MTIgNDAwTDQwMCA1MTJMNTEyIDYyNEw2MjQgNTEyTDUxMiA0MDBaIiBmaWxsPSIjQzBDMEMwIi8+Cjx0ZXh0IHg9IjUxMiIgeT0iNzAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSIjODA4MDgwIiBmb250LXNpemU9IjI0Ij5EZW1vIE1vZGU8L3RleHQ+Cjx0ZXh0IHg9IjUxMiIgeT0iNzMwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSIjODA4MDgwIiBmb250LXNpemU9IjE2Ij5Db25maWd1cmUgT3BlbkFJIEFQSSBrZXk8L3RleHQ+Cjwvc3ZnPgo=',
          revisedPrompt: `Demo Mode: Generated a placeholder for "${prompt}". Configure OPENAI_API_KEY to enable real AI image generation.`
        };
      }

      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: prompt,
        n: 1,
        size: "1024x1024",
        quality: "standard",
      });

      return {
        url: response.data[0].url,
        revisedPrompt: response.data[0].revised_prompt
      };
    } catch (error) {
      console.error('OpenAI image generation error:', error);
      // Return a placeholder instead of throwing
      return {
        url: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAyNCIgaGVpZ2h0PSIxMDI0IiB2aWV3Qm94PSIwIDAgMTAyNCAxMDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cmVjdCB3aWR0aD0iMTAyNCIgaGVpZ2h0PSIxMDI0IiBmaWxsPSIjRkZGMEYwIi8+CjxwYXRoIGQ9Ik01MTIgNDAwTDQwMCA1MTJMNTEyIDYyNEw2MjQgNTEyTDUxMiA0MDBaIiBmaWxsPSIjRkY4MDgwIi8+Cjx0ZXh0IHg9IjUxMiIgeT0iNzAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmaWxsPSIjODA0MDQwIiBmb250LXNpemU9IjI0Ij5FcnJvciBNb2RlPC90ZXh0Pgo8dGV4dCB4PSI1MTIiIHk9IjczMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iIzgwNDA0MCIgZm9udC1zaXplPSIxNiI+SW1hZ2UgZ2VuZXJhdGlvbiB1bmF2YWlsYWJsZTwvdGV4dD4KPC9zdmc+Cg==',
        revisedPrompt: `Error generating image for "${prompt}". ${error.message}`
      };
    }
  }

  getAvailableModels() {
    return Object.keys(this.models).map(key => ({
      id: key,
      name: key === 'gpt-5' ? 'GPT-5 (Latest)' : 
            key === 'gpt-4' ? 'GPT-4' : 
            'GPT-3.5 Turbo'
    }));
  }
}

module.exports = OpenAIService;