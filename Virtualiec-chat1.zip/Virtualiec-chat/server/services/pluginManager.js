/**
 * Plugin Manager for VirtualIEC
 * Provides a modular architecture for adding specialized AI skills and integrations
 */

class PluginManager {
  constructor() {
    this.plugins = new Map();
    this.hooks = new Map();
  }

  /**
   * Register a new plugin
   * @param {string} name - Plugin name
   * @param {Object} plugin - Plugin object with required methods
   */
  registerPlugin(name, plugin) {
    if (!plugin.initialize || typeof plugin.initialize !== 'function') {
      throw new Error('Plugin must have an initialize method');
    }

    this.plugins.set(name, plugin);
    plugin.initialize(this);
    console.log(`✅ Plugin registered: ${name}`);
  }

  /**
   * Unregister a plugin
   * @param {string} name - Plugin name
   */
  unregisterPlugin(name) {
    const plugin = this.plugins.get(name);
    if (plugin && plugin.cleanup) {
      plugin.cleanup();
    }
    this.plugins.delete(name);
    console.log(`🗑️  Plugin unregistered: ${name}`);
  }

  /**
   * Get a specific plugin
   * @param {string} name - Plugin name
   * @returns {Object|null} Plugin instance or null
   */
  getPlugin(name) {
    return this.plugins.get(name) || null;
  }

  /**
   * List all registered plugins
   * @returns {Array} Array of plugin names
   */
  listPlugins() {
    return Array.from(this.plugins.keys());
  }

  /**
   * Register a hook for extending functionality
   * @param {string} hookName - Name of the hook
   * @param {Function} callback - Callback function
   */
  addHook(hookName, callback) {
    if (!this.hooks.has(hookName)) {
      this.hooks.set(hookName, []);
    }
    this.hooks.get(hookName).push(callback);
  }

  /**
   * Execute all callbacks for a specific hook
   * @param {string} hookName - Hook name
   * @param {...any} args - Arguments to pass to callbacks
   * @returns {Promise<Array>} Array of results from all callbacks
   */
  async executeHook(hookName, ...args) {
    const callbacks = this.hooks.get(hookName) || [];
    const results = [];

    for (const callback of callbacks) {
      try {
        const result = await callback(...args);
        results.push(result);
      } catch (error) {
        console.error(`Hook execution error in ${hookName}:`, error);
        results.push({ error: error.message });
      }
    }

    return results;
  }

  /**
   * Process message through all enabled plugins
   * @param {string} message - User message
   * @param {Object} context - Request context
   * @returns {Promise<Object>} Enhanced message or plugin response
   */
  async processMessage(message, context) {
    // Execute pre-processing hooks
    await this.executeHook('beforeMessageProcess', message, context);

    // Check if any plugin should handle this message
    for (const [name, plugin] of this.plugins) {
      if (plugin.shouldHandle && plugin.shouldHandle(message, context)) {
        console.log(`🔌 Plugin ${name} handling message`);
        try {
          const result = await plugin.handleMessage(message, context);
          if (result) {
            // Execute post-processing hooks
            await this.executeHook('afterMessageProcess', result, context);
            return { pluginResult: result, handledBy: name };
          }
        } catch (error) {
          console.error(`Plugin ${name} error:`, error);
        }
      }
    }

    // Execute post-processing hooks for non-plugin messages
    await this.executeHook('afterMessageProcess', message, context);
    return null;
  }
}

// Example plugin structure for future developers
const ExamplePlugin = {
  name: 'ExamplePlugin',
  version: '1.0.0',
  
  initialize(pluginManager) {
    console.log('Example plugin initialized');
    // Add hooks, register services, etc.
    pluginManager.addHook('beforeMessageProcess', this.preprocessMessage.bind(this));
  },

  cleanup() {
    console.log('Example plugin cleaned up');
  },

  shouldHandle(message, context) {
    // Return true if this plugin should handle the message
    return message.toLowerCase().includes('example');
  },

  async handleMessage(message, context) {
    // Process the message and return a response
    return {
      content: `Example plugin processed: ${message}`,
      type: 'plugin_response'
    };
  },

  async preprocessMessage(message, context) {
    // Preprocess message before LLM
    console.log('Preprocessing message:', message);
    return message;
  }
};

module.exports = { PluginManager, ExamplePlugin };